package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class java_class {

	public static WebDriver dr;
	public void book() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://phptravels.net/home");
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		System.out.println("hotel");
		
		
		dr.findElement(By.xpath("//div[@class='dropdown dropdown-currency']/a")).click(); 
		Thread.sleep(3000);
		dr.findElement(By.xpath("//div[@class='dropdown-menu dropdown-menu-right show']/div[1]/a[4]")).click();
		Thread.sleep(3000);
		dr.findElement(By.xpath("//a[@data-name='flights']")).click();//select flights menu
		Thread.sleep(3000);
		
		
		
		
		dr.findElement(By.xpath("//div[@id='s2id_location_from']/a")).click();
		Thread.sleep(3000);
		dr.findElement(By.xpath("//div[@id='s2id_location_from']/a")).sendKeys("LAX");
		Thread.sleep(3000);
		dr.findElement(By.xpath("//div[@id='select2-drop']/ul/li[1]/div")).click();
		Thread.sleep(3000);
		
		dr.findElement(By.xpath("//div[@id='select2-drop']/div[1]/input")).click();
		Thread.sleep(10000);
		dr.findElement(By.xpath("//div[@id='s2id_location_to']/a")).sendKeys("DFW");
		Thread.sleep(3000);
		dr.findElement(By.xpath("//div[@id='select2-drop']/ul/li[1]/div"));
		Thread.sleep(3000);
		
		dr.findElement(By.xpath("//div[@class='col-xs-12 col-md-1']/button")).click();
	}
}
