package test_php;

import org.testng.annotations.Test;

import pages.java_class;

public class php_Test extends java_class {
	
  @Test
  public void f() throws InterruptedException {
	  book();
	  
	 
  }
}
